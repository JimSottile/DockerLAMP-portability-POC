<?php

$first = "Jim";
$last = "S";
$page = "https://github.com/tkyk/docker-compose-lamp";

echo "<center><b>=======================================================</b></center><br>";
echo "<b><center><header>Test Page POC " . $first . " " . $last . " using " . $page . " !</b></header></center><br>";
echo "<center><b>=======================================================</b></center>";
echo "<center>This is a POC test to show portability of contanerized LAMP.</center>";
echo "<br> ";
echo "<center>After uncompressing the archive<br> cd to docker-compose-lamp-master directory <br> then install docker-compose by running these commands:</center><br>";
echo "docker-compose build -d<br>";
echo "docker-compose up -d<br>";
echo " <br> ";
echo "<center>the purpose of this is to demonstrate the portability of the dockerized LAMP service.
</center><br>";
?>
